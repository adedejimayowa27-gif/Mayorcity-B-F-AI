# Ledger — Banking & Finance AI (personal site)

## What this is
A private website: a chat assistant grounded in your CIBN banking/finance
study packs (Digital Banking, Law of Banking, FIN 210, Finance in the
Global Market, past-question banks, Feb 2026 examiners' report).

The API key is kept server-side in a Netlify Function — never exposed
in the browser.

## Deploy steps

1. Create a new GitHub repo, push this whole folder to it.
2. In Netlify: "Add new site" -> "Import an existing project" -> pick that repo.
   Build settings are already set in netlify.toml (publish = "public",
   functions = "netlify/functions") — no build command needed.
3. In Netlify: Site settings -> Environment variables -> add:
   ANTHROPIC_API_KEY = <your key from console.anthropic.com>
4. Deploy. Netlify gives you a free `something.netlify.app` URL immediately.
5. To use your own domain: Site settings -> Domain management -> Add a
   domain, then point your domain's DNS to Netlify as instructed there.

## Updating the study material later
Send Claude the new PDFs; it'll regenerate public/index.html with the
updated knowledge base baked in — just replace that one file and redeploy
(or `git push` again).
